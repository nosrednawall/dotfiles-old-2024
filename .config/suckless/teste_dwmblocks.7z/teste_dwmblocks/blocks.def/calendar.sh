#!/bin/sh
ICON=""
printf "$ICON%s" "$(date '+%a, %b %d, %R')"
