//Modify this file to change what commands output to your statusbar, and recompile using the make command.
static const Block blocks[] = {
	/*Icon*/	/*Command*/		/*Update Interval*/	/*Update Signal*/

	{"", "/home/anderson/.dotfiles/.local/bin/statusbar/sb-brightness", 1, 1},
    {"", "/home/anderson/.dotfiles/.local/bin/statusbar/sb-volume", 1, 2},
    {"", "/home/anderson/.dotfiles/.local/bin/statusbar/sb-mic", 1, 3},
    {"", "/home/anderson/.dotfiles/.local/bin/statusbar/sb-record", 1, 4},
    {"", "/home/anderson/.dotfiles/.local/bin/statusbar/sb-keyboard", 1, 5},
    {"", "/home/anderson/.dotfiles/.local/bin/statusbar/sb-battery", 1, 6},
    {"", "/home/anderson/.dotfiles/.local/bin/statusbar/sb-date", 1, 7},
    {"", "/home/anderson/.dotfiles/.local/bin/statusbar/sb-hour", 1, 8},

};

//sets delimiter between status commands. NULL character ('\0') means no delimiter.
static char delim[] = " | ";
static unsigned int delimLen = 5;
